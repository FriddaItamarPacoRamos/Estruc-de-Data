
#pragma once
#include"Nodo.h"
#define MAX 100
class Cola
{
private:
	Nodo info[MAX];
	int ini, fin;
public:
	Cola();
	void Encolar(Nodo*& inicio, Nodo*& fin);
	void Desencolar(Nodo*& inicio);


};
