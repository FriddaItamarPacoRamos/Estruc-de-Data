#pragma once
#define MAX 100
#include<iostream>
using namespace std;
#include "Nodo.h"

    class Pila {
        Nodo* inicio;
private:
    float pila[MAX];
    float tope;
    float TipoDato;
public:
    Pila();
    bool Apilar(TipoDato& elemento);
    bool Desapilar();
    bool TopePila(TipoDato& elemento);
    void LimpiarPila();
    void VerPila();
    bool PilaVacia();
    bool Iguales(Pila p);

};