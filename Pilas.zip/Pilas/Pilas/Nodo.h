#pragma once
#include <iostream>
#include <string>
using namespace std;
class Nodo
{
public:
	float dato;
	string nombre;
	Nodo* sig;
};


