#include <iostream>
#include "Pila.h"
#include "Nodo.h"
using namespace std;

int main() {
    Nodo nuevo;
    Pila l;
    int opcion;
    do {
        system("cls");
        cout << "[1]Apilar" << endl;
        cout << "[2]Desapilar" << endl;
        cout << "[3]Tope Pila" << endl;
        cout << "[4]Limpiar pila" << endl;
        cout << "[5]Ver Pila" << endl;
        cout << "[6]Pila Vacia" << endl;
        cout << "[0]Salir" << endl;
        cout << "\nIngresa tu opcion: ";
      
        cin >> opcion;
        switch (opcion) {
        case 1:
            l.Apilar(TipoDato & elemento);
            break;
        case 2:
            l.Desapilar();
            break;
        case 3:
            l.TopePila(TipoDato & elemento);
            break;
        case 4:
            l.LimpiarPila();
            break;
        case 5:
            l.VerPila();
            break;
        case 6:
            l.PilaVacia();
            break;
        case 0:
            return 0;
            break;
        default:
            cout << "Por favor ingresa una opcion correcta.\n";
            break;
        }
    } while (opcion != 0);
    return 0;
}
