#include "Pila.h"
#include <iostream>
using namespace std;
Pila::Pila()
{
    tope = -1;
}
bool Pila::Apilar(TipoDato& elemento)
{
    bool res;
    if (tope == MAX - 1)
    {
        cout << "Desbordamiento de Pila (Overflow)" << endl;
        res = false;
    }
    else
    {
        tope++;
        pila[tope] = elemento;
        res = true;
    }
    return res;
}
bool Pila::Desapilar()
{
    bool res;
    if (tope == -1)
    {
        cerr << "Se esta intentando quitar un elemento de una pila vacia (underflow)" << endl;
        res = false;
    }
    else
    {
        tope--;
        res = true;
    }
    return res;
}
void Pila::VerPila()
{
    for (int i = 0; i <= tope; i++)
        cout << pila[i] << endl;
}
bool Pila::TopePila(TipoDato& elemento)
{
    bool res;
    if (PilaVacia())//(tope == -1)
    {
        cerr << "Se esta intentando quitar un elemento de una pila vacia (underflow)" << endl;
        res = false;
    }
    else
    {
        pila[tope];
        tope--;
        res = true;
    }
    return res;
}
bool Pila::PilaVacia()
{
    return tope == -1;
}
void Pila::LimpiarPila()
{
    tope = -1;
}
bool Pila::Iguales(Pila p)
{
    TipoDato a, b;
    TipoDato array[MAX];
    bool iguales = false;
    int i = tope;
    while (p.TopePila(b) && array[i--] == b)
    {
        p.Desapilar();
    }
    if (i < 0 && p.PilaVacia())
        iguales = true;
    return iguales;
}